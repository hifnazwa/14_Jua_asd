import java.util.ArrayList;

public class TransaksiBarang14 {
    private ArrayList<Barang14> barangs;

    public TransaksiBarang14() {
        this.barangs = new ArrayList<>();
    }

    public void tambahBarang(Barang14 barang) {
        this.barangs.add(barang);
    }

    public void tampilkanBarang() {
        System.out.println("=============================");
        System.out.println("        Daftar Barang");
        System.out.println("=============================");
        System.out.printf("%-40s %-15s %-15s %-15s \n", "Kode", "Nama", "Harga", "Stock");
        System.out.println("--------------------------------------------------------------------------");
        for (Barang14 barang : barangs) {
            System.out.printf("%-43s %-17s %-14s %-1s \n", barang.getKode(), barang.getNama(), barang.getHarga(), barang.getStok());
        }
    }

    public void tampilkanPembelian() {
        System.out.println("=============================");
        System.out.println("        Daftar Pembelian");
        System.out.println("=============================");
        System.out.printf("%-40s %-15s %-15s %-15s \n", "Kode", "Nama", "Harga", "Stock");
        System.out.println("--------------------------------------------------------------------------");
        for (Barang14 barang : barangs) {
            System.out.printf("%-43s %-17s %-14s %-1s \n", barang.getKode(), barang.getNama(), barang.getHarga(), barang.getStok());
        }
    }

    public void pembelian(String kode) {
        Barang14 barang = null;
        for (Barang14 b : barangs) {
            if (b.getKode().equals(kode)) {
                barang = b;
                break;
            }
        }

        if (barang != null) {
            if (barang.getStok() > 0) {
                barang.setStok(barang.getStok() - 1);
                System.out.println("Pembelian berhasil.");
            } else {
                System.out.println("Stok barang habis.");
            }
        } else {
            System.out.println("Barang tidak ditemukan.");
        }
    }
}